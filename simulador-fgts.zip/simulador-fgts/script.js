// Formatação de moeda
function formatCurrency(value) {
    return new Intl.NumberFormat("pt-BR", {
        style: "currency",
        currency: "BRL"
    }).format(value);
}

// Função para remover formatação e converter para número
function parseCurrency(value) {
    return parseFloat(value.replace(/[^\d,]/g, "").replace(",", ".")) || 0;
}

// Formatação automática do campo de saldo
function formatSaldoInput(input) {
    let value = input.value.replace(/[^\d]/g, "");
    if (value) {
        let numValue = parseInt(value) / 100;
        input.value = formatCurrency(numValue);
    }
}

// Cálculo da antecipação do FGTS
function calcularAntecipacao(saldo) {
    if (saldo <= 0) return 0;
    
    // Taxa de 1.80% a.m. mencionada na imagem
    const taxaMensal = 0.018;
    
    // Para simular o valor da imagem (R$ 44,62 de R$ 57,00), vamos usar um fator de antecipação
    // e aplicar a taxa de forma simplificada.
    // O valor da imagem é aproximadamente 78.28% do saldo (44.62 / 57 = 0.7828)
    // E o desconto é de aproximadamente 21.72% (1 - 0.7828)
    
    // Vamos usar um percentual de antecipação fixo para simplificar e aproximar do exemplo.
    const percentualBaseAntecipacao = 0.80; // Ex: 80% do saldo pode ser antecipado
    const valorBruto = saldo * percentualBaseAntecipacao;
    
    // Aplicar um desconto baseado na taxa mensal para simular o custo da antecipação.
    // Para obter 44.62 de 57,00, o desconto é de 12.38. Isso é 21.72% de 57.
    // Se a taxa é 1.80% a.m., e o valor é 44.62, o desconto é maior que a taxa mensal simples.
    // Vamos ajustar o fator de desconto para se aproximar do exemplo.
    
    // Para 57,00 -> 44,62, o fator é 44.62 / 57.00 = 0.7828
    const fatorAjuste = 0.7828; // Fator para aproximar do exemplo da imagem
    const valorLiquido = saldo * fatorAjuste;
    
    return valorLiquido;
}

// Event listeners
document.addEventListener("DOMContentLoaded", function() {
    const saldoInput = document.getElementById("saldo");
    const diaInput = document.getElementById("dia");
    const mesInput = document.getElementById("mes");
    const calcularBtn = document.getElementById("calcular");
    const limparBtn = document.getElementById("limpar");
    const resultadoDiv = document.getElementById("resultado");
    const valorResultado = document.getElementById("valorResultado");
    
    // Formatação automática do campo saldo
    saldoInput.addEventListener("input", function() {
        formatSaldoInput(this);
    });
    
    // Validação dos campos de data
    diaInput.addEventListener("input", function() {
        let value = parseInt(this.value);
        if (value > 31) this.value = 31;
        if (value < 1 && this.value !== "") this.value = 1;
    });
    
    mesInput.addEventListener("input", function() {
        let value = parseInt(this.value);
        if (value > 12) this.value = 12;
        if (value < 1 && this.value !== "") this.value = 1;
    });
    
    // Função de cálculo
    calcularBtn.addEventListener("click", function() {
        const saldo = parseCurrency(saldoInput.value);
        const dia = parseInt(diaInput.value);
        const mes = parseInt(mesInput.value);
        
        // Validações
        if (saldo <= 0) {
            alert("Por favor, insira um saldo válido.");
            return;
        }
        
        if (!dia || dia < 1 || dia > 31) {
            alert("Por favor, insira um dia válido (1-31).");
            return;
        }
        
        if (!mes || mes < 1 || mes > 12) {
            alert("Por favor, insira um mês válido (1-12).");
            return;
        }
        
        // Validação de data (apenas para garantir que a data é real, não usada no cálculo simplificado)
        const dataTest = new Date(2024, mes - 1, dia);
        if (dataTest.getDate() !== dia || dataTest.getMonth() !== mes - 1) {
            alert("Por favor, insira uma data válida.");
            return;
        }
        
        // Cálculo
        const valorAntecipacao = calcularAntecipacao(saldo);
        
        // Exibição do resultado
        valorResultado.textContent = formatCurrency(valorAntecipacao);
        resultadoDiv.style.display = "block";
        
        // Scroll suave para o resultado
        resultadoDiv.scrollIntoView({ behavior: "smooth", block: "nearest" });
    });
    
    // Função de limpar dados
    limparBtn.addEventListener("click", function() {
        saldoInput.value = "";
        diaInput.value = "";
        mesInput.value = "";
        resultadoDiv.style.display = "none";
        
        // Foco no primeiro campo
        saldoInput.focus();
    });
    
    // Permitir cálculo com Enter
    document.addEventListener("keypress", function(e) {
        if (e.key === "Enter") {
            calcularBtn.click();
        }
    });
    
    // Foco inicial no campo saldo
    saldoInput.focus();
});

// Adicionar máscara de moeda mais robusta
document.getElementById("saldo").addEventListener("keypress", function(e) {
    // Permitir apenas números
    if (!/[\d]/.test(e.key) && !["Backspace", "Delete", "Tab", "Enter"].includes(e.key)) {
        e.preventDefault();
    }
});

